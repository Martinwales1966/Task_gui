let tasks = [
    { text: "Design homepage", done: false },
    { text: "Fix login bug", done: true },
    { text: "Write documentation", done: false }
];

function updateDashboard() {
    const taskList = document.getElementById("tasks");
    const taskCount = document.getElementById("taskCount");
    const completedCount = document.getElementById("completedCount");

    taskList.innerHTML = "";
    let completed = 0;

    tasks.forEach((task, index) => {
        const li = document.createElement("li");
        li.textContent = task.text;
        if (task.done) {
            li.classList.add("completed");
            completed++;
        }
        li.onclick = () => toggleTask(index);
        taskList.appendChild(li);
    });

    taskCount.textContent = tasks.length;
    completedCount.textContent = completed;
}

function addTask() {
    const input = document.getElementById("newTask");
    const taskText = input.value.trim();
    if (taskText) {
        tasks.push({ text: taskText, done: false });
        input.value = "";
        updateDashboard();
    }
}

function toggleTask(index) {
    tasks[index].done = !tasks[index].done;
    updateDashboard();
}

updateDashboard();
